# Ismakov-et-al.-Matlab-code
Matlab code used in Ismakov et al., 2017

Please have a look at the file "Matlab analysis readme file.docx" for explanations about the different functions
