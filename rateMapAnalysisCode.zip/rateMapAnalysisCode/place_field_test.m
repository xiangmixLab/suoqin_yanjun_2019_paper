figure
subplot(1,3,3)
imagesc(rate_mat);axis xy; axis off; hold on;
plot(max_inds(:,2),max_inds(:,1), 'kx','Markersize',5, 'linewidth',5)
axis ij
shading flat;colormap(jet)